<style>
  /* Premium Footer Custom Styles */
  .footer {
    background-color: #0e0e0e !important;
    color: #c4c4c4 !important;
    padding: 40px 0px 0px 0px !important;
  }

  .footer h6 {
    color: #ffffff !important;
    font-weight: 700 !important;
    font-size: 16px !important;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    padding-bottom: 12px;
    margin-bottom: 25px !important;
  }

  .footer h6::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 35px;
    height: 2px;
    background-color: #a17a42;
    /* Gold accent color */
  }

  .footer .menu-footer {
    padding-left: 0;
    margin-bottom: 0;
  }

  .footer .menu-footer li {
    margin-bottom: 12px !important;
    list-style: none;
  }

  .footer .menu-footer li a {
    color: #b0b0b0 !important;
    font-size: 15px !important;
    text-decoration: none !important;
    transition: all 0.25s ease-in-out;
    display: inline-block;
  }

  .footer .menu-footer li a:hover {
    color: #a17a42 !important;
    transform: translateX(5px);
  }

  .footer-top {
    border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
    padding-bottom: 30px !important;
    margin-bottom: 40px !important;
  }

  .footer .footer-bottom {
    border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
    padding: 30px 0px 20px 0px !important;
    margin-top: 40px !important;
  }

  .need-help {
    color: #b0b0b0 !important;
    text-decoration: none !important;
    transition: color 0.2s ease;
    font-size: 15px;
  }

  .need-help:hover {
    color: #a17a42 !important;
  }

  .phone-support {
    color: #a17a42 !important;
    font-weight: 700 !important;
    font-size: 22px !important;
    margin-left: 15px;
    text-decoration: none !important;
    transition: transform 0.2s ease, color 0.2s ease;
    display: inline-block;
  }

  .phone-support:hover {
    color: #ffffff !important;
    transform: scale(1.03);
  }

  /* Socials styling */
  .box-socials-footer {
    margin-top: 15px;
  }

  .box-socials-footer a.icon-socials {
    background-color: rgba(255, 255, 255, 0.03) !important;
    border: 1px solid rgba(255, 255, 255, 0.08) !important;
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    width: 38px !important;
    height: 38px !important;
    border-radius: 50% !important;
    transition: all 0.3s ease !important;
    margin-right: 8px !important;
  }

  .box-socials-footer a.icon-socials svg {
    fill: #b0b0b0 !important;
    transition: fill 0.3s ease !important;
  }

  .box-socials-footer a.icon-socials:hover {
    background-color: #a17a42 !important;
    border-color: #a17a42 !important;
    transform: translateY(-4px) !important;
    box-shadow: 0 4px 12px rgba(161, 122, 66, 0.3);
  }

  .box-socials-footer a.icon-socials:hover svg {
    fill: #ffffff !important;
  }

  .footer-contact-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 16px;
  }

  .footer-contact-item svg {
    color: #a17a42;
    margin-top: 4px;
    flex-shrink: 0;
  }

  .footer-contact-item span {
    font-size: 14px;
    color: #b0b0b0;
    line-height: 1.6;
  }

  .menu-bottom-footer {
    padding-left: 0;
    margin-bottom: 0;
    list-style: none;
  }

  .menu-bottom-footer li {
    display: inline-block;
    margin-left: 20px;
  }

  .menu-bottom-footer li a {
    color: #b0b0b0 !important;
    font-size: 14px !important;
    text-decoration: none !important;
    transition: color 0.2s ease;
  }

  .menu-bottom-footer li a:hover {
    color: #a17a42 !important;
  }
</style>

<footer class="footer">
  <div class="container">
    <div class="footer-top">
      <div class="row align-items-center">
        <div class="col-md-4 text-center text-md-start">
          <a class="d-inline-block" href="index.php">
            <img alt="Hotel Destin" src="assets/imgs/template/logo-destin.png" style="max-height: 80px; width: auto;">
          </a>
        </div>
        <div class="col-md-8 text-center text-md-end">
          <?php
          $hotel_phone = get_setting('hotel_phone') ?: '1-800-222-8888';
          $phones = array_map('trim', explode(',', $hotel_phone));
          $first_phone = isset($phones[0]) ? $phones[0] : '1-800-222-8888';
          ?>
          <div class="d-flex align-items-center justify-content-center justify-content-md-end">
            <a class="text-md-medium need-help" href="tel:<?= htmlspecialchars($first_phone) ?>">Need help? Call us</a>
            <a class="heading-6 phone-support" href="tel:<?= htmlspecialchars($first_phone) ?>"><?= htmlspecialchars($first_phone) ?></a>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 col-sm-12 footer-1">
        <h6>Contact Us</h6>
        <div class="mt-20 mb-20">
          <div class="box-info-contact">
            <div class="footer-contact-item">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
              </svg>
              <span><?= htmlspecialchars(get_setting('hotel_address') ?: 'Hotel  destin Gwalior Sachin Tendulkar road Near Ram Vatika marriage garden Govindpuri Gwalior') ?></span>
            </div>
            <div class="footer-contact-item">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
              <span>Front Desk: 24 Hours, Mon - Sun</span>
            </div>
            <?php
            $hotel_email = get_setting('hotel_email') ?: 'info@hoteldestin.in';
            $emails = array_map('trim', explode(',', $hotel_email));
            $first_email = isset($emails[0]) ? $emails[0] : 'info@hoteldestin.in';
            ?>
            <div class="footer-contact-item">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
              </svg>
              <span><?= htmlspecialchars($first_email) ?></span>
            </div>
          </div>
          <p class="text-md-bold title-follow neutral-0" style="font-weight:700; margin-top:25px; color:#ffffff;">Follow us</p>
          <div class="box-socials-footer">
            <a class="icon-socials icon-instagram" href="<?= htmlspecialchars(get_setting('instagram_url') ?: 'https://www.instagram.com/destingwalior/?hl=en') ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13.4915 1.6665H6.50817C3.47484 1.6665 1.6665 3.47484 1.6665 6.50817V13.4832C1.6665 16.5248 3.47484 18.3332 6.50817 18.3332H13.4832C16.5165 18.3332 18.3248 16.5248 18.3248 13.4915V6.50817C18.3332 3.47484 16.5248 1.6665 13.4915 1.6665ZM9.99984 13.2332C8.2165 13.2332 6.7665 11.7832 6.7665 9.99984C6.7665 8.2165 8.2165 6.7665 9.99984 6.7665C11.7832 6.7665 13.2332 8.2165 13.2332 9.99984C13.2332 11.7832 11.7832 13.2332 9.99984 13.2332ZM14.9332 5.73317C14.8915 5.83317 14.8332 5.92484 14.7582 6.00817C14.6748 6.08317 14.5832 6.1415 14.4832 6.18317C14.3832 6.22484 14.2748 6.24984 14.1665 6.24984C13.9415 6.24984 13.7332 6.1665 13.5748 6.00817C13.4998 5.92484 13.4415 5.83317 13.3998 5.73317C13.3582 5.63317 13.3332 5.52484 13.3332 5.4165C13.3332 5.30817 13.3582 5.19984 13.3998 5.09984C13.4415 4.9915 13.4998 4.90817 13.5748 4.82484C13.7665 4.63317 14.0582 4.5415 14.3248 4.59984C14.3832 4.60817 14.4332 4.62484 14.4832 4.64984C14.5332 4.6665 14.5832 4.6915 14.6332 4.72484C14.6748 4.74984 14.7165 4.7915 14.7582 4.82484C14.8332 4.90817 14.8915 4.9915 14.9332 5.09984C14.9748 5.19984 14.9998 5.30817 14.9998 5.4165C14.9998 5.52484 14.9748 5.63317 14.9332 5.73317Z" fill="currentColor"></path>
              </svg>
            </a>
            <a class="icon-socials icon-facebook" href="#" aria-label="Facebook">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18.3334 13.4915C18.3334 16.5248 16.5251 18.3332 13.4917 18.3332H12.5001C12.0417 18.3332 11.6667 17.9582 11.6667 17.4998V12.6915C11.6667 12.4665 11.8501 12.2748 12.0751 12.2748L13.5417 12.2498C13.6584 12.2415 13.7584 12.1582 13.7834 12.0415L14.0751 10.4498C14.1001 10.2998 13.9834 10.1582 13.8251 10.1582L12.0501 10.1832C11.8167 10.1832 11.6334 9.99985 11.6251 9.77485L11.5918 7.73317C11.5918 7.59984 11.7001 7.48318 11.8417 7.48318L13.8417 7.44984C13.9834 7.44984 14.0918 7.34152 14.0918 7.19985L14.0584 5.19983C14.0584 5.05816 13.9501 4.94984 13.8084 4.94984L11.5584 4.98318C10.1751 5.00818 9.07509 6.1415 9.10009 7.52484L9.14175 9.8165C9.15008 10.0498 8.96676 10.2332 8.73342 10.2415L7.73341 10.2582C7.59175 10.2582 7.48342 10.3665 7.48342 10.5082L7.50842 12.0915C7.50842 12.2332 7.61675 12.3415 7.75841 12.3415L8.75842 12.3248C8.99176 12.3248 9.17507 12.5082 9.18341 12.7332L9.2584 17.4832C9.26674 17.9498 8.89174 18.3332 8.42507 18.3332H6.50841C3.47508 18.3332 1.66675 16.5248 1.66675 13.4832V6.50817C1.66675 3.47484 3.47508 1.6665 6.50841 1.6665H13.4917C16.5251 1.6665 18.3334 3.47484 18.3334 6.50817V13.4915V13.4915Z" fill="currentColor"></path>
              </svg>
            </a>
            <a class="icon-socials icon-twitter" href="#" aria-label="Twitter">
              <svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.1924 3.06705L14.8565 5.40299C14.3846 10.8733 9.77132 15.1249 4.25022 15.1249C3.11585 15.1249 2.18069 14.9452 1.47053 14.5905C0.897878 14.3038 0.663503 13.9967 0.604909 13.9092C0.552663 13.8309 0.518798 13.7417 0.505847 13.6485C0.492895 13.5552 0.50119 13.4602 0.530113 13.3706C0.559036 13.2809 0.607839 13.199 0.672875 13.1309C0.737911 13.0628 0.817498 13.0102 0.905691 12.9772C0.926003 12.9694 2.79944 12.2499 3.98928 10.8803C3.32943 10.3378 2.75341 9.70072 2.27991 8.98971C1.31116 7.55143 0.226784 5.05299 0.561159 1.3194C0.571758 1.20076 0.616036 1.08762 0.688779 0.993308C0.761521 0.898992 0.859699 0.827427 0.971752 0.787039C1.0838 0.746651 1.20506 0.739122 1.32125 0.76534C1.43744 0.791557 1.54372 0.850429 1.62757 0.935022C1.65491 0.962365 4.22757 3.52096 7.37288 4.35065V3.87487C7.37168 3.37595 7.47032 2.88185 7.66299 2.42164C7.85566 1.96143 8.13847 1.54443 8.49475 1.19518C8.84077 0.849652 9.25248 0.576929 9.70561 0.393103C10.1587 0.209277 10.6441 0.11807 11.133 0.124865C11.7889 0.131335 12.432 0.307407 12.9997 0.635963C13.5674 0.964519 14.0405 1.43438 14.3729 1.99987H16.7502C16.8739 1.99977 16.9948 2.03637 17.0977 2.10504C17.2006 2.17371 17.2808 2.27136 17.3281 2.38562C17.3755 2.49989 17.3878 2.62563 17.3637 2.74693C17.3395 2.86823 17.2799 2.97964 17.1924 3.06705Z" fill="currentColor"></path>
              </svg>
            </a>
          </div>
        </div>
      </div>
      <div class="col-md-2 col-xs-6 footer-2">
        <h6>Our Hotel</h6>
        <ul class="menu-footer">
          <li><a href="about.php">About Us</a></li>
          <li><a href="rooms.php">Comfortable Rooms</a></li>
          <li><a href="restaurant.php">Dining & Restaurant</a></li>
          <li><a href="banquet.php">Banquet & Events</a></li>
          <li><a href="gallery.php">Photo Gallery</a></li>
        </ul>
      </div>
      <div class="col-md-2 col-xs-6 footer-3">
        <h6>Services</h6>
        <ul class="menu-footer">
          <li><a href="airport-transfer.php">Airport Transfer</a></li>
          <li><a href="corporate-booking.php">Corporate Booking</a></li>
          <li><a href="wedding-banquet.php">Banquet Hall</a></li>
          <li><a href="explore-gwalior.php">Tourist Attractions</a></li>

        </ul>
      </div>
      <div class="col-md-2 col-xs-6 footer-4">
        <h6>Information</h6>
        <ul class="menu-footer">
          <li><a href="blog.php">News & Blog</a></li>
          <li><a href="contact.php">Contact Us</a></li>
          <li><a href="contact.php#map">Location & Map</a></li>
          <li><a href="contact.php">Guest Support</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-xs-6 footer-5">
        <h6>Legal & Policies</h6>
        <ul class="menu-footer">
          <li><a href="terms.php">Terms of Service</a></li>
          <li><a href="terms.php">Privacy Policy</a></li>
          <li><a href="terms.php">Cookies Policy</a></li>
          <li><a href="terms.php">Refund Policy</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom mt-50">
      <div class="row">
        <div class="col-md-6 text-md-start text-center mb-20">
          <p class="text-sm color-white">© <?= date('Y') ?> Hotel Destin. All rights reserved.</p>
        </div>
        <div class="col-md-6 text-md-end text-center mb-20">
          <ul class="menu-bottom-footer">
            <li><a href="terms.php">Terms</a></li>
            <li><a href="terms.php">Privacy Policy</a></li>
            <li><a href="terms.php">Legal Notice</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>

<!-- Mobile Sticky Bottom Navigation -->
<div class="mobile-bottom-nav">
  <a href="index.php" class="nav-item <?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : '' ?>">
    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
      <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
    <span class="nav-label">Home</span>
  </a>

  <a href="rooms.php" class="nav-item <?= (basename($_SERVER['PHP_SELF']) == 'rooms.php') ? 'active' : '' ?>">
    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
    </svg>
    <span class="nav-label">Rooms</span>
  </a>

  <a href="javascript:void(0);" onclick="openEnquiryModal()" class="nav-item">
    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
    <span class="nav-label">Enquire Now</span>
  </a>

  <a href="gallery.php" class="nav-item <?= (basename($_SERVER['PHP_SELF']) == 'gallery.php') ? 'active' : '' ?>">
    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="7" height="7"></rect>
      <rect x="14" y="3" width="7" height="7"></rect>
      <rect x="14" y="14" width="7" height="7"></rect>
      <rect x="3" y="14" width="7" height="7"></rect>
    </svg>
    <span class="nav-label">Gallery</span>
  </a>

  <a href="contact.php" class="nav-item <?= (basename($_SERVER['PHP_SELF']) == 'contact.php') ? 'active' : '' ?>">
    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
    </svg>
    <span class="nav-label">Contact</span>
  </a>
</div>

<style>
  .mobile-bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 64px;
    background: #ffffffff;
    border-top: 1px solid rgba(224, 184, 93, 0.25);
    display: flex;
    justify-content: space-around;
    align-items: center;
    z-index: 99999;
    box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.4);
    padding-bottom: env(safe-area-inset-bottom);
  }

  .mobile-bottom-nav .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
    text-decoration: none;
    width: 20%;
    height: 100%;
    transition: color 0.25s ease, transform 0.2s ease;
  }

  .mobile-bottom-nav .nav-item .nav-icon {
    margin-bottom: 4px;
    transition: transform 0.25s ease;
  }

  .mobile-bottom-nav .nav-item .nav-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  .mobile-bottom-nav .nav-item:hover,
  .mobile-bottom-nav .nav-item.active {
    color: #E0B85D;
  }

  .mobile-bottom-nav .nav-item:active .nav-icon {
    transform: scale(0.9);
  }

  @media (min-width: 768px) {
    .mobile-bottom-nav {
      display: none !important;
    }
  }

  @media (max-width: 767px) {
    body {
      padding-bottom: 74px !important;
    }
  }
</style>

<!-- Floating Share Location Button -->
<button class="floating-share-location-btn" onclick="openShareModal(event)" title="Share Hotel Location">
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" style="color: #ffffff;">
    <circle cx="18" cy="5" r="3"></circle>
    <circle cx="6" cy="12" r="3"></circle>
    <circle cx="18" cy="19" r="3"></circle>
    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
  </svg>
</button>

<!-- Share Modal Overlay -->
<div class="share-modal-overlay" id="shareModalOverlay" style="display: none;">
  <div class="share-modal-card">
    <div class="share-modal-header">
      <h3 class="share-modal-title">Share</h3>
      <button type="button" class="share-modal-close" onclick="closeShareModal()">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <!-- Platform Icons Container -->
    <div class="share-platforms-row">
      <!-- WhatsApp -->
      <a href="https://api.whatsapp.com/send?text=Check%20out%20Hotel%20Destin%20on%20Google%20Maps%3A%20https%3A%2F%2Fwww.google.com%2Fmaps%2Fsearch%2F%3Fapi%3D1%26query%3DHotel%2BDESTIN%2BGWALIOR" target="_blank" class="share-platform-item">
        <div class="share-platform-icon whatsapp">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2zm0 1.62c4.57 0 8.29 3.72 8.29 8.29s-3.72 8.29-8.29 8.29c-1.55 0-3.03-.43-4.31-1.24l-.31-.18-3.09.81.82-3.01-.2-.32a8.23 8.23 0 0 1-1.27-4.35c0-4.57 3.72-8.29 8.29-8.29zm-3.66 4.28c-.18 0-.44.07-.67.33-.23.26-.88.86-.88 2.1s.9 2.44 1.03 2.61c.13.17 1.77 2.7 4.28 3.78.6.26 1.07.41 1.43.53.6.19 1.15.16 1.58.1.48-.07 1.48-.6 1.69-1.19.21-.58.21-1.09.15-1.19-.06-.1-.23-.17-.48-.29l-2.52-1.24c-.25-.13-.44-.19-.63.09l-.72.9c-.16.2-.33.22-.58.09-.26-.13-1.09-.4-2.07-1.28-.76-.68-1.27-1.52-1.42-1.78-.15-.26-.02-.4.11-.53l.51-.6c.13-.15.17-.26.26-.43a.47.47 0 0 0-.02-.45c-.06-.13-.59-1.42-.81-1.95-.21-.52-.43-.45-.59-.46l-.5-.01z" />
          </svg>
        </div>
        <span class="share-platform-label">WhatsApp</span>
      </a>

      <!-- X (Twitter) -->
      <a href="https://twitter.com/intent/tweet?text=Check%20out%20Hotel%20Destin%20on%20Google%20Maps%3A%20https%3A%2F%2Fwww.google.com%2Fmaps%2Fsearch%2F%3Fapi%3D1%26query%3DHotel%2BDESTIN%2BGWALIOR" target="_blank" class="share-platform-item">
        <div class="share-platform-icon twitter-x">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
        </div>
        <span class="share-platform-label">X</span>
      </a>

      <!-- LinkedIn -->
      <a href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.google.com%2Fmaps%2Fsearch%2F%3Fapi%3D1%26query%3DHotel%2BDESTIN%2BGWALIOR" target="_blank" class="share-platform-item">
        <div class="share-platform-icon linkedin">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z" />
          </svg>
        </div>
        <span class="share-platform-label">LinkedIn</span>
      </a>

      <!-- Email -->
      <a href="mailto:?subject=Hotel%20Destin%20Gwalior&body=Check%20out%20Hotel%20Destin%20Gwalior%20on%20Google%20Maps%3A%20https%3A%2F%2Fwww.google.com%2Fmaps%2Fsearch%2F%3Fapi%3D1%26query%3DHotel%2BDESTIN%2BGWALIOR" class="share-platform-item">
        <div class="share-platform-icon email">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
          </svg>
        </div>
        <span class="share-platform-label">Email</span>
      </a>
    </div>

    <!-- URL Sharing Copy Block -->
    <div class="share-url-container">
      <input type="text" class="share-url-input" value="https://www.google.com/maps/search/?api=1&query=Hotel+DESTIN+GWALIOR" readonly id="shareUrlInputField">
      <button type="button" onclick="window.copyMapLocation()" class="share-url-copy-btn" id="shareUrlCopyBtn">Copy</button>
    </div>
  </div>
</div>

<!-- Copy Success Toast Alert -->
<div id="shareCopyToast" style="display: none; position: fixed; bottom: 100px; left: 30px; background: #0f172a; color: #ffffff; padding: 10px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 100000; animation: callFadeIn 0.2s ease;">
  Link copied to clipboard!
</div>

<style>
  /* Floating Share Location Button styling */
  .floating-share-location-btn {
    position: fixed;
    bottom: 30px;
    left: 30px;
    z-index: 9999;
    width: 50px;
    height: 50px;
    background: #a17a42;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 15px rgba(161, 122, 66, 0.4);
    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border: 2px solid #ffffff;
    cursor: pointer;
    padding: 0;
  }

  .floating-share-location-btn:hover {
    transform: scale(1.08);
    background: #8c6734;
  }

  /* Share Modal Overlay styling (High Fidelity YouTube style) */
  .share-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(15, 23, 42, 0.55);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: shareFadeIn 0.25s ease forwards;
  }

  .share-modal-card {
    background: #ffffff;
    border-radius: 12px;
    padding: 24px;
    width: 90%;
    max-width: 440px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
    border: 1px solid #e2e8f0;
    position: relative;
    transform: scale(0.95);
    animation: shareScaleUp 0.25s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
  }

  .share-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
  }

  .share-modal-title {
    font-size: 18px;
    font-weight: 700;
    color: #0f172a;
    margin: 0;
  }

  .share-modal-close {
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px;
    color: #94a3b8;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.2s ease;
  }

  .share-modal-close:hover {
    background: #f1f5f9;
    color: #0f172a;
  }

  /* Horizontal platforms row - Centered for 4 items */
  .share-platforms-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 24px;
    margin-bottom: 24px;
  }

  .share-platform-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    text-decoration: none !important;
    min-width: 60px;
    cursor: pointer;
  }

  .share-platform-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    transition: transform 0.2s ease;
  }

  .share-platform-item:hover .share-platform-icon {
    transform: scale(1.08);
  }

  .share-platform-icon.whatsapp {
    background-color: #25D366;
  }

  .share-platform-icon.twitter-x {
    background-color: #0f172a;
  }

  .share-platform-icon.linkedin {
    background-color: #0a66c2;
  }

  .share-platform-icon.email {
    background-color: #64748b;
  }

  .share-platform-label {
    font-size: 11px;
    font-weight: 600;
    color: #64748b;
    text-align: center;
    white-space: nowrap;
  }

  /* URL container styling */
  .share-url-container {
    display: flex;
    align-items: center;
    background-color: #f8fafc;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 6px 6px 6px 14px;
    justify-content: space-between;
    gap: 10px;
  }

  .share-url-input {
    border: none;
    background: transparent;
    font-size: 13.5px;
    color: #334155;
    flex-grow: 1;
    outline: none;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    padding: 0;
  }

  .share-url-copy-btn {
    background-color: #065fd4;
    color: #ffffff;
    border: none;
    border-radius: 18px;
    padding: 8px 18px;
    font-size: 13.5px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .share-url-copy-btn:hover {
    background-color: #054eb0;
  }

  @keyframes shareFadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  @keyframes shareScaleUp {
    from {
      transform: scale(0.95);
      opacity: 0;
    }

    to {
      transform: scale(1);
      opacity: 1;
    }
  }

  @media (max-width: 767px) {
    .floating-share-location-btn {
      bottom: 84px;
      left: 20px;
      width: 46px;
      height: 46px;
    }

    #shareCopyToast {
      bottom: 150px;
      left: 20px;
    }
  }

  /* Hourly Stay Room Cards Styling */
  .hourly-room-card {
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.25s;
    position: relative;
  }

  .hourly-room-card:hover {
    border-color: #cbd5e1;
  }

  .hourly-room-card.selected {
    border-color: #a17a42 !important;
    background: rgba(161, 122, 66, 0.03) !important;
    box-shadow: 0 4px 10px rgba(161, 122, 66, 0.1) !important;
  }

  .hourly-room-card.selected::before {
    content: '✓';
    position: absolute;
    top: 4px;
    right: 4px;
    background: #a17a42;
    color: #fff;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    font-size: 10px;
    line-height: 16px;
    text-align: center;
    z-index: 5;
  }
</style>

<?php
// Load hourly stay package rates
$hourly_packages = [
  'standard' => [3 => 600, 6 => 1000, 9 => 1400, 12 => 1800],
  'executive' => [3 => 800, 6 => 1300, 9 => 1800, 12 => 2200],
  'premium' => [3 => 1000, 6 => 1600, 9 => 2200, 12 => 2800]
];
try {
  if (isset($pdo)) {
    $keys = [
      'hourly_3_standard',
      'hourly_6_standard',
      'hourly_9_standard',
      'hourly_12_standard',
      'hourly_3_executive',
      'hourly_6_executive',
      'hourly_9_executive',
      'hourly_12_executive',
      'hourly_3_premium',
      'hourly_6_premium',
      'hourly_9_premium',
      'hourly_12_premium'
    ];
    $stmt_h = $pdo->query("SELECT key_name, val_content FROM settings WHERE key_name IN ('" . implode("','", $keys) . "')");
    while ($row_h = $stmt_h->fetch()) {
      $parts = explode('_', $row_h['key_name']);
      if (count($parts) === 3) {
        $hours = (int)$parts[1];
        $category = $parts[2];
        $hourly_packages[$category][$hours] = (float)$row_h['val_content'];
      }
    }
  }
} catch (Exception $e) {
  // Fail silently
}

// Load room categories and main images dynamically
$hourly_rooms = [];
try {
  if (isset($pdo)) {
    $stmt_r = $pdo->query("SELECT id, title, image_path FROM rooms WHERE id IN (1, 2, 3) ORDER BY id ASC");
    $hourly_rooms = $stmt_r->fetchAll(PDO::FETCH_ASSOC);
  }
} catch (Exception $e) {
  // Fail silently
}
// Fallback if empty
if (count($hourly_rooms) < 3) {
  $hourly_rooms = [
    ['id' => 1, 'title' => 'Standard Room - Hotel Destin', 'image_path' => 'assets/imgs/page/room/banner-room.png'],
    ['id' => 2, 'title' => 'Executive Room - Hotel Destin', 'image_path' => 'assets/imgs/page/room/banner-room2.png'],
    ['id' => 3, 'title' => 'Premium Room - Hotel Destin', 'image_path' => 'assets/imgs/page/pages/banner.png']
  ];
}
?>

<!-- Hourly Stay Modal -->
<div class="modal fade" id="hourlyStayModal" tabindex="-1" aria-labelledby="hourlyStayModalLabel" aria-hidden="true" style="z-index: 99999;">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius: 16px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.15);">
      <div class="modal-header border-bottom-0" style="padding: 25px 30px 10px 30px;">
        <h3 class="modal-title font-heading" id="hourlyStayModalLabel" style="font-size: 20px; color: #0f172a; font-weight: 700;">Book Hourly Stay</h3>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="font-size: 14px;"></button>
      </div>
      <div class="modal-body" style="padding: 10px 30px 30px 30px;">
        <div id="hourlyBookingAlert" class="alert d-none" role="alert" style="border-radius: 8px; font-size: 14px; padding: 10px 15px;"></div>
        <form id="hourlyBookingForm">
          <input type="hidden" name="csrf_token" value="<?= isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '' ?>">

          <div class="row mb-15">
            <div class="col-md-6">
              <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Full Name *</label>
              <input type="text" name="name" class="form-control" placeholder="Enter your name" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
            <div class="col-md-6 mt-15 mt-md-0">
              <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Phone Number *</label>
              <input type="tel" name="phone" class="form-control" placeholder="10-digit mobile number" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
          </div>

          <div class="row mb-15">
            <div class="col-md-6">
              <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Stay Date *</label>
              <input type="date" name="stay_date" id="hourlyStayDate" class="form-control" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
            <div class="col-md-6 mt-15 mt-md-0">
              <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Check-in Time *</label>
              <input type="time" name="checkin_time" class="form-control" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
          </div>

          <div class="form-group mb-15">
            <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Stay Duration *</label>
            <select name="hours" id="hourlyStayHours" class="form-control" style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
              <option value="3">3 Hours Package</option>
              <option value="6">6 Hours Package</option>
              <option value="9">9 Hours Package</option>
              <option value="12">12 Hours Package</option>
            </select>
          </div>

          <div class="form-group mb-15">
            <label class="form-label-custom" style="font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 8px; display: block;">Select Room Category *</label>
            <div class="row g-2" id="hourlyRoomContainer">
              <?php
              $slugs = ['standard', 'executive', 'premium'];
              foreach ($hourly_rooms as $index => $hr):
                $slug = $slugs[$index];
                $init_price = $hourly_packages[$slug][3];
              ?>
                <div class="col-4">
                  <div class="hourly-room-card text-center <?= $index === 0 ? 'selected' : '' ?>" data-slug="<?= $slug ?>" onclick="selectHourlyRoom(this)">
                    <input type="radio" name="room_category" value="<?= htmlspecialchars($hr['title']) ?>" class="d-none" id="roomRadio_<?= $slug ?>" <?= $index === 0 ? 'checked' : '' ?> required>
                    <img src="<?= htmlspecialchars($hr['image_path']) ?>" alt="<?= htmlspecialchars($hr['title']) ?>" style="height: 60px; width: 100%; object-fit: cover;">
                    <div style="padding: 6px 4px;">
                      <h6 style="font-size: 11px; font-weight: 700; margin-bottom: 1px; color: #0f172a; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;" title="<?= htmlspecialchars($hr['title']) ?>"><?= htmlspecialchars($slug === 'standard' ? 'Standard' : ($slug === 'executive' ? 'Executive' : 'Premium')) ?></h6>
                      <div class="room-total-badge" style="font-size: 10px; font-weight: 700; color: #a17a42; background: #faf5eb; border-radius: 4px; padding: 1px 3px; display: inline-block;">₹<?= number_format($init_price) ?></div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>

          <div style="background: #f8fafc; border-radius: 8px; padding: 12px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
            <div class="d-flex justify-content-between align-items-center">
              <span style="font-size: 13px; font-weight: 600; color: #475569;">Calculated Total Price:</span>
              <span id="hourlyCalcTotal" style="font-size: 18px; font-weight: 800; color: #a17a42;">₹1,000</span>
            </div>
          </div>

          <button type="submit" id="hourlySubmitBtn" class="btn w-100" style="background: #a17a42; color: #fff; font-weight: 700; padding: 12px; border-radius: 8px; border: none; font-size: 15px; cursor: pointer; transition: all 0.2s;">
            Confirm Hourly Stay Request
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Bulk Booking Modal -->
<div class="modal fade" id="bulkBookingModal" tabindex="-1" aria-labelledby="bulkBookingModalLabel" aria-hidden="true" style="z-index: 99999;">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius: 16px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.15);">
      <div class="modal-header border-bottom-0" style="padding: 25px 30px 10px 30px;">
        <h3 class="modal-title font-heading" id="bulkBookingModalLabel" style="font-size: 20px; color: #0f172a; font-weight: 700;">Book Entire Hotel</h3>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="font-size: 14px;"></button>
      </div>
      <div class="modal-body" style="padding: 10px 30px 30px 30px;">
        <div id="bulkBookingAlert" class="alert d-none" role="alert" style="border-radius: 8px; font-size: 14px; padding: 10px 15px;"></div>
        <form id="bulkBookingForm">
          <input type="hidden" name="csrf_token" value="<?= isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '' ?>">

          <div class="form-group mb-15">
            <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Full Name *</label>
            <input type="text" name="name" class="form-control" placeholder="Enter your full name" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
          </div>

          <div class="row mb-15">
            <div class="col-md-6">
              <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Email Address *</label>
              <input type="email" name="email" class="form-control" placeholder="e.g. name@domain.com" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
            <div class="col-md-6 mt-15 mt-md-0">
              <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Phone Number *</label>
              <input type="tel" name="phone" class="form-control" placeholder="10-digit mobile number" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
          </div>

          <div class="row mb-15">
            <div class="col-md-6">
              <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Check-in Date *</label>
              <input type="date" name="checkin" id="bulkCheckin" class="form-control" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
            <div class="col-md-6 mt-15 mt-md-0">
              <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Check-out Date *</label>
              <input type="date" name="checkout" id="bulkCheckout" class="form-control" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
            </div>
          </div>

          <div class="form-group mb-15">
            <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Approx. Guests Count *</label>
            <input type="number" name="guests" class="form-control" min="1" placeholder="Estimated total number of guests" required style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px;">
          </div>

          <div class="form-group mb-20">
            <label class="form-label-custom" style="font-size: 13.5px; font-weight: 600; color: #475569; margin-bottom: 6px; display: block;">Special Requirements / Message</label>
            <textarea name="requirements" class="form-control" rows="3" placeholder="Tell us about catering requirements, hall requirements, or event configurations..." style="border-radius: 8px; padding: 10px 14px; border: 1px solid #cbd5e1; width: 100%; box-sizing: border-box; font-size: 14.5px; resize: none;"></textarea>
          </div>

          <button type="submit" id="bulkSubmitBtn" class="btn w-100" style="background: #a17a42; color: #fff; font-weight: 700; padding: 12px; border-radius: 8px; border: none; font-size: 15px; cursor: pointer; transition: all 0.2s;">
            Submit Request
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Prevent past dates in Check-in and Check-out
    var today = new Date().toISOString().split('T')[0];
    var checkinInput = document.getElementById('bulkCheckin');
    var checkoutInput = document.getElementById('bulkCheckout');
    if (checkinInput && checkoutInput) {
      checkinInput.setAttribute('min', today);
      checkinInput.addEventListener('change', function() {
        if (this.value) {
          var parts = this.value.split('-');
          var checkInDate = new Date(parts[0], parts[1] - 1, parts[2]);
          checkInDate.setDate(checkInDate.getDate() + 1);
          
          var yyyy = checkInDate.getFullYear();
          var mm = String(checkInDate.getMonth() + 1).padStart(2, '0');
          var dd = String(checkInDate.getDate()).padStart(2, '0');
          var minCheckoutDate = yyyy + '-' + mm + '-' + dd;
          
          checkoutInput.setAttribute('min', minCheckoutDate);
          if (!checkoutInput.value || checkoutInput.value <= this.value) {
            checkoutInput.value = minCheckoutDate;
          }
        } else {
          checkoutInput.setAttribute('min', today);
        }
      });
    }

    var form = document.getElementById('bulkBookingForm');
    var alertBox = document.getElementById('bulkBookingAlert');
    var submitBtn = document.getElementById('bulkSubmitBtn');

    if (form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Disable button and show loading text
        submitBtn.disabled = true;
        submitBtn.innerText = 'Submitting Request...';

        // Build form data
        var formData = new FormData(form);

        // Send AJAX post
        fetch('submit-bulk-booking.php', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            alertBox.className = 'alert ' + (data.success ? 'alert-success' : 'alert-danger');
            alertBox.innerText = data.message;
            alertBox.classList.remove('d-none');

            if (data.success) {
              form.reset();
              // Auto-hide modal after 3.5 seconds
              setTimeout(function() {
                var modalEl = document.getElementById('bulkBookingModal');
                var modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) {
                  modal.hide();
                }
                alertBox.classList.add('d-none');
              }, 3500);
            }
          })
          .catch(error => {
            alertBox.className = 'alert alert-danger';
            alertBox.innerText = 'Something went wrong. Please try again.';
            alertBox.classList.remove('d-none');
            console.error('Error:', error);
          })
          .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerText = 'Submit Request';
          });
      });
    }

    // Hourly Stay Modal Calculator & Submit Logic
    var hourlyForm = document.getElementById('hourlyBookingForm');
    var hourlyAlertBox = document.getElementById('hourlyBookingAlert');
    var hourlySubmitBtn = document.getElementById('hourlySubmitBtn');
    var hourlyHoursSelect = document.getElementById('hourlyStayHours');
    var hourlyDateInput = document.getElementById('hourlyStayDate');

    if (hourlyDateInput) {
      hourlyDateInput.setAttribute('min', today);
    }

    const hourlyRatesMatrix = <?= json_encode($hourly_packages) ?>;

    function calculateHourlyTotals() {
      var hours = parseInt(hourlyHoursSelect.value) || 3;
      var cards = document.querySelectorAll('#hourlyRoomContainer .hourly-room-card');
      var selectedCard = document.querySelector('#hourlyRoomContainer .hourly-room-card.selected');

      // Update each card badge price display
      cards.forEach(function(card) {
        var slug = card.getAttribute('data-slug');
        var total = hourlyRatesMatrix[slug][hours] || 0;
        var badge = card.querySelector('.room-total-badge');
        if (badge) {
          badge.innerText = '₹' + total.toLocaleString('en-IN');
        }
      });

      // Update summary total
      if (selectedCard) {
        var slug = selectedCard.getAttribute('data-slug');
        var total = hourlyRatesMatrix[slug][hours] || 0;
        var summaryText = document.getElementById('hourlyCalcTotal');
        if (summaryText) {
          summaryText.innerText = '₹' + total.toLocaleString('en-IN');
        }
      }
    }

    if (hourlyHoursSelect) {
      hourlyHoursSelect.addEventListener('change', calculateHourlyTotals);
    }

    // Expose selectHourlyRoom globally
    window.selectHourlyRoom = function(card) {
      document.querySelectorAll('#hourlyRoomContainer .hourly-room-card').forEach(function(c) {
        c.classList.remove('selected');
        var radio = c.querySelector('input[type="radio"]');
        if (radio) radio.checked = false;
      });
      card.classList.add('selected');
      var radio = card.querySelector('input[type="radio"]');
      if (radio) {
        radio.checked = true;
      }
      calculateHourlyTotals();
    };

    if (hourlyForm) {
      // Trigger initial calculation
      calculateHourlyTotals();

      hourlyForm.addEventListener('submit', function(e) {
        e.preventDefault();

        hourlySubmitBtn.disabled = true;
        hourlySubmitBtn.innerText = 'Submitting Request...';

        var formData = new FormData(hourlyForm);

        // Fetch selected hourly details to submit
        var selectedCard = document.querySelector('#hourlyRoomContainer .hourly-room-card.selected');
        if (selectedCard) {
          var slug = selectedCard.getAttribute('data-slug');
          var hours = parseInt(hourlyHoursSelect.value) || 3;
          var total = hourlyRatesMatrix[slug][hours] || 0;
          formData.append('hourly_rate', total / hours); // average hourly rate
        }

        fetch('submit-hourly-booking.php', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            hourlyAlertBox.className = 'alert ' + (data.success ? 'alert-success' : 'alert-danger');
            hourlyAlertBox.innerText = data.message;
            hourlyAlertBox.classList.remove('d-none');

            if (data.success) {
              hourlyForm.reset();
              // Reset selection to standard
              document.querySelectorAll('#hourlyRoomContainer .hourly-room-card').forEach(function(c, idx) {
                if (idx === 0) {
                  c.classList.add('selected');
                  c.querySelector('input[type="radio"]').checked = true;
                } else {
                  c.classList.remove('selected');
                  c.querySelector('input[type="radio"]').checked = false;
                }
              });
              calculateHourlyTotals();

              // Auto-hide modal after 4 seconds
              setTimeout(function() {
                var modalEl = document.getElementById('hourlyStayModal');
                var modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) {
                  modal.hide();
                }
                hourlyAlertBox.classList.add('d-none');
              }, 4000);
            }
          })
          .catch(error => {
            hourlyAlertBox.className = 'alert alert-danger';
            hourlyAlertBox.innerText = 'Something went wrong. Please try again.';
            hourlyAlertBox.classList.remove('d-none');
            console.error('Error:', error);
          })
          .finally(() => {
            hourlySubmitBtn.disabled = false;
            hourlySubmitBtn.innerText = 'Confirm Hourly Stay Request';
          });
      });
    }

    window.openShareModal = function(e) {
      if (e) {
        e.stopPropagation();
      }
      document.getElementById('shareModalOverlay').style.display = 'flex';
      document.body.style.overflow = 'hidden';
    };

    window.closeShareModal = function() {
      document.getElementById('shareModalOverlay').style.display = 'none';
      document.body.style.overflow = '';
    };

    window.copyMapLocation = function() {
      var inputField = document.getElementById('shareUrlInputField');
      var copyBtn = document.getElementById('shareUrlCopyBtn');
      if (!inputField) return;

      inputField.select();
      inputField.setSelectionRange(0, 99999);

      navigator.clipboard.writeText(inputField.value).then(function() {
        if (copyBtn) {
          var originalText = copyBtn.innerText;
          copyBtn.innerText = 'Copied!';
          copyBtn.style.backgroundColor = '#10b981'; // green color feedback
          setTimeout(function() {
            copyBtn.innerText = originalText;
            copyBtn.style.backgroundColor = '';
          }, 2000);
        }

        var toast = document.getElementById('shareCopyToast');
        if (toast) {
          toast.innerText = 'Link copied to clipboard!';
          toast.style.display = 'block';
          setTimeout(function() {
            toast.style.display = 'none';
          }, 3000);
        }

        // Auto-close modal after 1.5 seconds so user can see copied status
        setTimeout(window.closeShareModal, 1500);
      }).catch(function(err) {
        console.error('Could not copy text: ', err);
      });
    };

    // Close share modal when clicking outside
    var overlay = document.getElementById('shareModalOverlay');
    if (overlay) {
      overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
          window.closeShareModal();
        }
      });
    }
  });
</script>