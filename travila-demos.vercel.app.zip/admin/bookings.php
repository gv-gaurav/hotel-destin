<?php
ob_start();
require_once __DIR__ . '/includes/header.php';

$success_message = '';
$error_message = '';

if (isset($_GET['success'])) {
    $success_message = 'Reservation payment status updated successfully!';
}
if (isset($_GET['delete']) && $_GET['delete'] === 'success') {
    $success_message = 'Reservation record permanently deleted successfully!';
}
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'csrf') $error_message = 'Security check failed. Please refresh and try again.';
    else if ($_GET['error'] === 'status') $error_message = 'Invalid reservation status selection.';
    else if ($_GET['error'] === 'db') $error_message = 'Failed to update reservation status in database.';
    else if ($_GET['error'] === 'delete') $error_message = 'Failed to delete reservation record.';
}

// Handle booking deletion (Developer only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_booking') {
    if (!is_developer()) {
        header("Location: bookings.php?error=unauthorized");
        exit;
    }

    $csrf_token = isset($_POST['csrf_token']) ? trim($_POST['csrf_token']) : '';
    if (!verify_csrf_token($csrf_token)) {
        header("Location: bookings.php?error=csrf");
        exit;
    }

    $booking_db_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    if ($booking_db_id > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
            $stmt->execute([$booking_db_id]);
            header("Location: bookings.php?delete=success");
            exit;
        } catch (Exception $e) {
            error_log("Failed to delete booking: " . $e->getMessage());
            header("Location: bookings.php?error=delete");
            exit;
        }
    }
}

// Handle booking status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $csrf_token = isset($_POST['csrf_token']) ? trim($_POST['csrf_token']) : '';

    if (!verify_csrf_token($csrf_token)) {
        header("Location: bookings.php?error=csrf");
        exit;
    } else {
        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
        $status = isset($_POST['status']) ? trim($_POST['status']) : '';

        $allowed_statuses = ['pending', 'paid', 'cancelled'];
        if (!in_array($status, $allowed_statuses)) {
            header("Location: bookings.php?error=status");
            exit;
        } else {
            try {
                if ($status === 'paid') {
                    $b_stmt = $pdo->prepare("SELECT invoice_no, booking_status FROM bookings WHERE id = ?");
                    $b_stmt->execute([$booking_id]);
                    $row = $b_stmt->fetch();
                    $current_invoice = $row['invoice_no'] ?? '';
                    $current_booking_status = $row['booking_status'] ?? 'pending';

                    // Update booking_status to 'confirmed' only if it was pending or cancelled
                    $new_booking_status = in_array($current_booking_status, ['pending', 'cancelled']) ? 'confirmed' : $current_booking_status;

                    if (empty($current_invoice)) {
                        $date_prefix = 'INV-' . date('Ymd') . '-';
                        $seq_stmt = $pdo->prepare("SELECT invoice_no FROM bookings WHERE invoice_no LIKE ? ORDER BY invoice_no DESC LIMIT 1");
                        $seq_stmt->execute([$date_prefix . '%']);
                        $last_invoice = $seq_stmt->fetchColumn();
                        if ($last_invoice) {
                            $seq = (int)substr($last_invoice, -4);
                            $next_seq = str_pad($seq + 1, 4, '0', STR_PAD_LEFT);
                        } else {
                            $next_seq = '0001';
                        }
                        $invoice_no = $date_prefix . $next_seq;

                        $stmt = $pdo->prepare("UPDATE bookings SET payment_status = 'paid', booking_status = ?, invoice_no = ?, cancellation_reason = NULL WHERE id = ?");
                        $stmt->execute([$new_booking_status, $invoice_no, $booking_id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE bookings SET payment_status = 'paid', booking_status = ?, cancellation_reason = NULL WHERE id = ?");
                        $stmt->execute([$new_booking_status, $booking_id]);
                    }
                } else if ($status === 'cancelled') {
                    $cancellation_reason = isset($_POST['cancellation_reason']) ? trim($_POST['cancellation_reason']) : '';

                    $b_stmt = $pdo->prepare("SELECT payment_status FROM bookings WHERE id = ?");
                    $b_stmt->execute([$booking_id]);
                    $current_payment_status = $b_stmt->fetchColumn();

                    if ($current_payment_status === 'paid') {
                        $stmt = $pdo->prepare("UPDATE bookings SET booking_status = 'cancelled', payment_status = 'refunded', cancellation_reason = ? WHERE id = ?");
                        $stmt->execute([$cancellation_reason, $booking_id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE bookings SET booking_status = 'cancelled', cancellation_reason = ? WHERE id = ?");
                        $stmt->execute([$cancellation_reason, $booking_id]);
                    }
                } else {
                    // status is 'pending'
                    $stmt = $pdo->prepare("UPDATE bookings SET payment_status = 'pending', booking_status = 'pending', cancellation_reason = NULL WHERE id = ?");
                    $stmt->execute([$booking_id]);
                }
                header("Location: bookings.php?success=1");
                exit;
            } catch (Exception $e) {
                error_log("Booking status update failure: " . $e->getMessage());
                header("Location: bookings.php?error=db");
                exit;
            }
        }
    }
}

// Fetch bookings from database with filters
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : '';
$phone = isset($_GET['phone']) ? trim($_GET['phone']) : '';

$bookings = [];
try {
    $query = "
        SELECT b.*, r.title as room_title 
        FROM bookings b 
        LEFT JOIN rooms r ON b.room_id = r.id
    ";
    $conditions = [];
    $params = [];

    if ($start_date !== '') {
        $conditions[] = "b.created_at >= :start_date";
        $params['start_date'] = $start_date . " 00:00:00";
    }
    if ($end_date !== '') {
        $conditions[] = "b.created_at <= :end_date";
        $params['end_date'] = $end_date . " 23:59:59";
    }
    if ($phone !== '') {
        $conditions[] = "b.customer_phone LIKE :phone";
        $params['phone'] = '%' . $phone . '%';
    }

    if (count($conditions) > 0) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }

    $query .= " ORDER BY b.id DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Bookings listing DB load failure: " . $e->getMessage());
}
?>

<div class="d-flex justify-content-between align-items-center mb-35">
    <div>
        <h1 class="panel-title mb-0" style="font-size:26px;">Manage Reservations</h1>
        <p class="text-sm text-neutral-500 mt-5">Track online room bookings, payment statuses, and print guest invoice receipts.</p>
    </div>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show mb-25" style="border-radius: 8px; font-size:14px; padding: 12px 20px;">
        <?= htmlspecialchars($success_message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-25" style="border-radius: 8px; font-size:14px; padding: 12px 20px;">
        <?= htmlspecialchars($error_message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="panel-card">
    <h3 class="font-heading" style="font-size:18px;">Master Booking Register</h3>

    <!-- Search & Filter Bar -->
    <form method="GET" class="row g-3 align-items-end mb-30" style="background-color: #fafaf9; padding: 18px; border-radius: 12px; border: 1px solid #f1f1f0; margin: 0 0 25px 0;">
        <div class="col-6 col-md-3">
            <label class="form-label mb-5" style="font-size:12px; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:0.5px;">From Date</label>
            <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date) ?>" style="font-size: 13px; height: 38px; border-radius: 8px; border: 1px solid #cbd5e1; background-color: #ffffff; color: #334155; font-weight: 550;">
        </div>
        <div class="col-6 col-md-3">
            <label class="form-label mb-5" style="font-size:12px; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:0.5px;">To Date</label>
            <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date) ?>" style="font-size: 13px; height: 38px; border-radius: 8px; border: 1px solid #cbd5e1; background-color: #ffffff; color: #334155; font-weight: 550;">
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label mb-5" style="font-size:12px; font-weight:700; color:#475569; text-transform:uppercase; letter-spacing:0.5px;">Phone Number</label>
            <input type="text" name="phone" class="form-control" placeholder="Search phone number..." value="<?= htmlspecialchars($phone) ?>" style="font-size: 13px; height: 38px; border-radius: 8px; border: 1px solid #cbd5e1; background-color: #ffffff; color: #334155; font-weight: 550;">
        </div>
        <div class="col-12 col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-primary" style="height: 38px; padding: 0 15px; border-radius: 8px; font-weight:700; font-size:13px; background-color:#9c6047; border:none; transition: all 0.2s ease; flex-grow: 1;" onmouseover="this.style.backgroundColor='#824c36';" onmouseout="this.style.backgroundColor='#9c6047';">
                🔍 Filter
            </button>
            <?php if ($start_date !== '' || $end_date !== '' || $phone !== ''): ?>
                <a href="bookings.php" class="btn btn-light border d-inline-flex align-items-center justify-content-center" style="height: 38px; padding: 0 15px; border-radius: 8px; font-weight:700; font-size:13px; border-color:#cbd5e1; color:#475569; background-color:#ffffff; text-decoration:none;">
                    Reset
                </a>
            <?php endif; ?>

            <a href="export-bookings.php?start_date=<?= urlencode($start_date) ?>&end_date=<?= urlencode($end_date) ?>&phone=<?= urlencode($phone) ?>" class="btn btn-success ms-auto d-inline-flex align-items-center gap-2" style="height: 38px; padding: 0 12px; border-radius: 8px; font-weight:700; font-size:13px; background-color:#16a34a; border:none; color:#ffffff; text-decoration:none; transition: all 0.2s ease;" onmouseover="this.style.backgroundColor='#15803d';" onmouseout="this.style.backgroundColor='#16a34a';" title="Export to Excel">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                </svg>
                Export
            </a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table-custom">
            <thead>
                <tr>
                    <th>Ref ID / Guest Details</th>
                    <th>Room Reserved</th>
                    <th>Stay Dates</th>
                    <th>Amount Details</th>
                    <th>Method</th>
                    <th>Razorpay ID</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($bookings) > 0): ?>
                    <?php foreach ($bookings as $b): ?>
                        <tr>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <strong style="color: #9c6047;">#<?= htmlspecialchars($b['booking_id']) ?></strong><br>
                                <span style="font-size:11.5px; font-weight:700; color:#555;"><?= htmlspecialchars($b['invoice_no'] ?: 'Pending Invoicing') ?></span><br>
                                <strong style="color:#334155;"><?= htmlspecialchars($b['customer_name']) ?></strong><br>
                                <span style="font-size:12.5px; color:#64748b;"><?= htmlspecialchars($b['customer_email']) ?></span><br>
                                <span style="font-size:12px; color:#64748b;"><?= htmlspecialchars($b['customer_phone']) ?></span>
                                <?php if ($b['booking_status'] === 'cancelled' && !empty($b['cancellation_reason'])): ?>
                                    <div class="mt-5 text-danger" style="font-size:11.5px; line-height: 1.3;">
                                        <strong>Reason:</strong> <?= htmlspecialchars($b['cancellation_reason']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <strong style="color:#334155; font-size:13.5px;"><?= htmlspecialchars($b['room_title'] ?: 'Deluxe Room') ?></strong>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <span style="font-size:13.5px; font-weight:600; color:#334155;"><?= date('d M Y', strtotime($b['check_in'])) ?></span><br>
                                <span style="font-size:12px; color:#64748b; font-weight:550;">to</span><br>
                                <span style="font-size:13.5px; font-weight:600; color:#334155;"><?= date('d M Y', strtotime($b['check_out'])) ?></span><br>
                                <span style="font-size:11.5px; color:#888880; font-weight:600;">(<?= htmlspecialchars($b['total_nights']) ?> night(s))</span>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <strong style="font-size:14.5px; color:#0f172a;">₹<?= number_format($b['total_amount'], 2) ?></strong><br>
                                <span style="font-size:11.5px; color:#64748b;">Base: ₹<?= number_format($b['base_amount'], 2) ?></span><br>
                                <?php if (!empty($b['coupon_code'])): ?>
                                    <span class="badge bg-light text-success border mt-5" style="font-size:10px; padding:3px 6px; font-weight:700;">Used: <?= htmlspecialchars($b['coupon_code']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <?php
                                $method_bg = '#eff6ff';
                                $method_color = '#1d4ed8';
                                $method_border = '#bfdbfe';
                                if ($b['payment_method'] === 'Pay at Hotel') {
                                    $method_bg = '#fff7ed';
                                    $method_color = '#c2410c';
                                    $method_border = '#ffedd5';
                                }
                                ?>
                                <span class="badge" style="background-color: <?= $method_bg ?>; color: <?= $method_color ?>; border: 1px solid <?= $method_border ?>; font-size: 11px; padding: 4px 8px; border-radius: 4px; font-weight: 700; text-transform: uppercase;">
                                    <?= htmlspecialchars($b['payment_method'] ?: 'Razorpay') ?>
                                </span>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <span style="font-family:Courier, monospace; font-size:12.5px; color:#475569; font-weight:600;">
                                    <?= htmlspecialchars($b['razorpay_payment_id'] ?: 'N/A') ?>
                                </span>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <?php
                                $status_bg = '#ef4444'; // Red for cancelled/failed/refunded
                                $status_text = $b['payment_status'];
                                if ($b['booking_status'] === 'cancelled') {
                                    $status_text = 'cancelled';
                                } else if ($b['payment_status'] === 'paid') {
                                    $status_bg = '#10b981'; // Green
                                } else if ($b['payment_status'] === 'pending') {
                                    $status_bg = '#f59e0b'; // Yellow
                                }
                                ?>
                                <span class="badge" style="background-color: <?= $status_bg ?>; color: #ffffff; font-size: 11px; padding: 5px 10px; border-radius: 4px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">
                                    <?= htmlspecialchars($status_text) ?>
                                </span>
                            </td>
                            <td style="vertical-align: middle; padding: 16px 12px;">
                                <div class="d-flex flex-column gap-2" style="width: 130px;">
                                    <!-- Edit Status Form -->
                                    <form action="bookings.php" method="POST" style="margin:0;">
                                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                        <input type="hidden" name="action" value="update_status">
                                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">

                                        <select class="form-select" name="status" onchange="handleStatusChange(this)" style="font-size: 12px; font-weight: 700; padding: 6px 10px; border-radius: 6px; border: 1px solid #cbd5e1; height: 34px; background-color: #ffffff; width: 100%; color: #334155;">
                                            <option value="pending" <?= ($b['booking_status'] !== 'cancelled' && $b['payment_status'] === 'pending') ? 'selected' : '' ?>>Pending</option>
                                            <option value="paid" <?= ($b['booking_status'] !== 'cancelled' && $b['payment_status'] === 'paid') ? 'selected' : '' ?>>Paid</option>
                                            <option value="cancelled" <?= $b['booking_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                        </select>
                                    </form>

                                    <!-- Horizontal Actions Strip -->
                                    <div class="d-flex align-items-center justify-content-between gap-1">
                                        <!-- View Details -->
                                        <a href="booking-details.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center" style="padding: 6px; border-radius: 6px; width: 38px; height: 32px; color: #64748b;" title="View Details">
                                            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                            </svg>
                                        </a>

                                        <!-- Print Receipt link -->
                                        <a href="../invoice.php?ref=<?= urlencode($b['booking_id']) ?>&print=true" target="_blank" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center" style="padding: 6px; border-radius: 6px; width: 38px; height: 32px; border-color: #cbd5e1; color: #16a34a;" title="Print Receipt">
                                            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
                                            </svg>
                                        </a>

                                        <!-- Delete Reservation Form (Developer Only) -->
                                        <?php if (is_developer()): ?>
                                            <form action="bookings.php" method="POST" onsubmit="return confirm('DEVELOPER ACTION: Are you sure you want to permanently delete this booking?');" style="margin: 0; display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                <input type="hidden" name="action" value="delete_booking">
                                                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-light border d-inline-flex align-items-center justify-content-center text-danger" style="padding: 6px; border-radius: 6px; width: 38px; height: 32px; border-color: #cbd5e1;" title="Developer only: Delete Record">
                                                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-40 text-neutral-500">No room booking logs exist in the system database.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function handleStatusChange(selectElement) {
    if (selectElement.value === 'cancelled') {
        const reason = prompt('Please enter the reason for cancellation (optional):');
        if (reason === null) {
            // Restore select element value to default
            selectElement.value = [...selectElement.options].find(opt => opt.defaultSelected).value;
            return;
        }
        // Append hidden cancellation_reason to the form
        const reasonInput = document.createElement('input');
        reasonInput.type = 'hidden';
        reasonInput.name = 'cancellation_reason';
        reasonInput.value = reason;
        selectElement.form.appendChild(reasonInput);
    }
    selectElement.form.submit();
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>