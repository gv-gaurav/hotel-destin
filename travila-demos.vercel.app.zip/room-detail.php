<?php
require_once __DIR__ . '/db.php';

// Parse query parameters
$room_slug = isset($_GET['room']) ? trim($_GET['room']) : '';
$checkin = isset($_GET['checkin']) ? trim($_GET['checkin']) : '';
$checkout = isset($_GET['checkout']) ? trim($_GET['checkout']) : '';
$adults = isset($_GET['adults']) ? intval($_GET['adults']) : 2;
$children = isset($_GET['children']) ? min(2, max(0, intval($_GET['children']))) : 0;
$child_ages_param = isset($_GET['child_ages']) ? trim($_GET['child_ages']) : '';
$child_ages = !empty($child_ages_param) ? explode(',', $child_ages_param) : [];

$room = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE slug = ? OR id = ? AND status = 'active'");
    $stmt->execute([$room_slug, $room_slug]);
    $room = $stmt->fetch();
} catch (Exception $e) {
    error_log("Failed to fetch room detail: " . $e->getMessage());
}

if (!$room) {
    // Attempt fallback query to see if slug matches standard/executive/premium
    try {
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE slug LIKE ? AND status = 'active' LIMIT 1");
        $stmt->execute(['%' . $room_slug . '%']);
        $room = $stmt->fetch();
    } catch (Exception $e) {
    }
}

if (!$room) {
    // If no room is found, use a default fallback to prevent 404
    $room = [
        'id' => 1,
        'slug' => 'standard-room',
        'title' => 'Standard Room - Hotel Destin',
        'type' => 'Standard',
        'price' => 2000.00,
        'struck_price' => 4000.00,
        'discount' => '50% off',
        'description' => 'A beautifully designed cozy standard room featuring premium air conditioning, high speed Wi-Fi access, clean premium towels, custom tea kettle set, and comfortable bedding.',
        'image_path' => 'assets/imgs/page/room/banner-room.png'
    ];
}

// Fetch facilities
$facilities = [];
try {
    $f_stmt = $pdo->prepare("SELECT facility_name FROM room_facilities WHERE room_id = ?");
    $f_stmt->execute([$room['id']]);
    $facilities = $f_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $facilities = ['Free Wi-Fi', 'Mineral Water', 'AC', 'Tea/Coffee Maker', 'Premium Bathroom Amenities'];
}

// Fetch other images for gallery slider
$images = [];
try {
    $img_stmt = $pdo->prepare("SELECT image_path FROM room_images WHERE room_id = ?");
    $img_stmt->execute([$room['id']]);
    $images = $img_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
}

if (empty($images)) {
    $images = [$room['image_path']];
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="<?= htmlspecialchars($room['meta_description'] ?: $room['description']) ?>">
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/template/favicon.png">
    <link href="assets/css/stylee209.css?v=1.0.0" rel="stylesheet">
    <title><?= htmlspecialchars($room['title']) ?> - Hotel Destin Gwalior</title>

    <style>
        :root {
            --primary-gold: #9c6047;
            --primary-gold-hover: #834f37;
            --primary-gold-light: #fdfaf7;
            --charcoal: #0f172a;
            --light-bg: #fafaf9;
            --border-color: #cbd5e1;
        }

        body {
            background-color: #faf9f6;
            color: #334155;
        }

        /* Hero Banner Info */
        .room-detail-hero-box {
            background: #ffffff;
            border-bottom: 1px solid #f1f1ee;
            padding: 20px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.01);
        }

        .back-link {
            text-decoration: none;
            color: #64748b;
            font-size: 13px;
            font-weight: 700;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
        }

        .back-link:hover {
            color: var(--primary-gold);
            transform: translateX(-3px);
        }

        /* Gallery Layout */
        .gallery-main {
            border-radius: 16px;
            overflow: hidden;
            background: #eaeae7;
            margin-bottom: 12px;
            height: 380px;
            border: 1px solid #e5e5e0;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.04);
            position: relative;
        }

        .gallery-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .gallery-main:hover img {
            transform: scale(1.02);
        }

        .gallery-thumbs {
            display: flex;
            gap: 10px;
            overflow-x: auto;
            padding-bottom: 6px;
        }

        .gallery-thumbs::-webkit-scrollbar {
            height: 3px;
        }

        .gallery-thumbs::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }

        .gallery-thumb {
            width: 75px;
            height: 55px;
            border-radius: 10px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            opacity: 0.65;
            transition: all 0.25s ease;
            background: #eaeae7;
            flex-shrink: 0;
        }

        .gallery-thumb.active,
        .gallery-thumb:hover {
            border-color: var(--primary-gold);
            opacity: 1;
            transform: translateY(-1px);
        }

        .gallery-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Cards and Details */
        .detail-card {
            background: #ffffff;
            border: 1px solid #f0f0ed;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.015);
            margin-bottom: 16px;
        }

        .detail-card h3 {
            font-size: 17px;
            font-weight: 800;
            margin-bottom: 16px;
            color: var(--charcoal);
            border-bottom: 1px solid #f5f5f3;
            padding-bottom: 8px;
            letter-spacing: -0.3px;
            position: relative;
        }

        .detail-card h3::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 30px;
            height: 2px;
            background-color: var(--primary-gold);
            border-radius: 1px;
        }

        .specs-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #f1f1f0;
        }

        .spec-item {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #fafaf9;
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px solid #f0f0ed;
            transition: all 0.2s ease;
        }

        .spec-item:hover {
            transform: translateY(-2px);
            border-color: var(--primary-gold);
            background: #ffffff;
        }

        .spec-icon {
            font-size: 18px;
            color: var(--primary-gold);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .spec-info {
            display: flex;
            flex-direction: column;
        }

        .spec-label {
            font-size: 9.5px;
            font-weight: 700;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 1px;
        }

        .spec-value {
            font-size: 12.5px;
            font-weight: 700;
            color: var(--charcoal);
        }

        /* Amenities Grid */
        .amenity-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 10px;
        }

        .amenity-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 13px;
            color: #475569;
            padding: 8px 12px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .amenity-item:hover {
            border-color: var(--primary-gold);
            background: #fafaf9;
        }

        .amenity-check {
            color: var(--primary-gold);
            font-weight: 800;
            font-size: 12px;
            width: 18px;
            height: 18px;
            background: rgba(156, 96, 71, 0.08);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        /* Config Stay and Booking Form Inputs */
        .form-control-custom {
            height: 40px !important;
            border-radius: 8px !important;
            border: 1px solid #cbd5e1 !important;
            background-color: #ffffff !important;
            padding: 6px 12px !important;
            font-size: 13px !important;
            transition: all 0.2s ease !important;
            font-weight: 500 !important;
            color: var(--charcoal) !important;
        }

        .form-control-custom:focus {
            border-color: var(--primary-gold) !important;
            box-shadow: 0 0 0 3px rgba(156, 96, 71, 0.1) !important;
            outline: none !important;
        }

        .form-label-custom {
            font-size: 10.5px !important;
            text-transform: uppercase !important;
            letter-spacing: 0.5px !important;
            color: #64748b !important;
            font-weight: 700 !important;
            margin-bottom: 4px !important;
            display: block !important;
        }

        /* Config Stay and Booking Form */
        .tariff-option-card {
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            padding: 14px 16px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.25s ease;
            position: relative;
            background: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .tariff-option-card:hover {
            border-color: var(--primary-gold);
            transform: translateY(-1px);
        }

        .tariff-option-card.selected {
            border-color: var(--primary-gold);
            background: var(--primary-gold-light);
            box-shadow: 0 4px 12px rgba(156, 96, 71, 0.04);
        }

        .tariff-content {
            padding-right: 15px;
            flex-grow: 1;
        }

        .tariff-title {
            font-weight: 800;
            font-size: 14px;
            color: var(--charcoal);
            margin-bottom: 2px;
        }

        .tariff-desc {
            font-size: 11.5px;
            color: #64748b;
            margin-bottom: 6px;
            font-weight: 500;
            line-height: 1.4;
        }

        .tariff-price {
            font-size: 16px;
            font-weight: 800;
            color: #15803d;
        }

        .tariff-radio {
            position: relative;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            border: 2px solid #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: all 0.2s ease;
            background: #ffffff;
        }

        .tariff-option-card.selected .tariff-radio {
            border-color: var(--primary-gold);
            background: var(--primary-gold);
        }

        .tariff-option-card.selected .tariff-radio::after {
            content: '';
            width: 6px;
            height: 6px;
            background: #ffffff;
            border-radius: 50%;
            display: block;
        }

        .tariff-option-card input[type="radio"] {
            display: none;
        }

        /* Sticky Form Bar */
        .sticky-form-sidebar {
            position: sticky;
            top: 100px;
        }

        .btn-book-online {
            background: var(--charcoal);
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 14px;
            padding: 12px 24px;
            transition: all 0.2s ease;
            width: 100%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-book-online:hover {
            background: var(--primary-gold);
            color: #ffffff;
            transform: translateY(-1px);
        }

        .btn-book-online:disabled {
            background: #cbd5e1 !important;
            color: #94a3b8 !important;
            cursor: not-allowed !important;
            transform: none !important;
            box-shadow: none !important;
            opacity: 0.65;
        }

        @media (max-width: 991px) {
            .gallery-main {
                height: 300px;
            }

            .sticky-form-sidebar {
                position: relative;
                top: 0;
                margin-top: 20px;
            }

            .specs-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 767px) {
            .gallery-main {
                height: 220px;
            }

            .specs-grid {
                grid-template-columns: 1fr;
                gap: 8px;
            }

            .detail-card {
                padding: 16px;
            }

            .room-detail-hero-box h1 {
                font-size: 24px !important;
            }

            .tariff-option-card {
                padding: 12px;
            }

            .tariff-title {
                font-size: 13.5px;
            }

            .tariff-desc {
                font-size: 11px;
            }

            .tariff-price {
                font-size: 15px;
            }

            .amenity-grid {
                grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
            }
        }
    </style>
    <?php include("include/head-scripts.php"); ?>
</head>

<body>

    <?php include("include/header.php"); ?>

    <main class="main">
        <!-- Hero Title Banner Section -->
        <section class="room-detail-hero-box mb-20">
            <div class="container">
                <a href="rooms.php" class="back-link mb-10">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="margin-right:6px;">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to All Rooms
                </a>

                <div class="row align-items-end mt-10">
                    <div class="col-lg-8 col-12">
                        <span class="badge" style="background-color: rgba(156, 96, 71, 0.08); color: var(--primary-gold); font-weight: 700; padding: 6px 12px; font-size:11px; border-radius: 4px; letter-spacing: 0.6px; text-transform: uppercase; margin-bottom: 8px; display: inline-block;">
                            <?= htmlspecialchars($room['type']) ?> Accommodations
                        </span>
                        <h1 class="font-heading mb-10" style="font-size: 30px; font-weight: 800; color: var(--charcoal); letter-spacing: -0.5px; line-height:1.2;">
                            <?= htmlspecialchars($room['title']) ?>
                        </h1>
                        <p class="neutral-500 mb-0" style="font-size: 14px; font-weight: 600; color: #64748b;">
                            📍 Hotel destin Gwalior Sachin Tendulkar road Near Ram Vatika marriage garden Govindpuri Gwalior
                        </p>
                    </div>
                    <div class="col-lg-4 col-12 text-lg-end mt-20 mt-lg-0">
                        <div class="rating-info-badge d-inline-flex align-items-center gap-2" style="background: #ffffff; border: 1px solid #e2e8f0; padding: 8px 16px; border-radius: 30px;">
                            <span style="color:#d97706; font-size:15px;">★</span>
                            <span style="font-weight: 700; font-size:13px; color: var(--charcoal);">G 4.8 / 5 Rating</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Room Detail and Booking Interface -->
        <section class="section-box pb-40">
            <div class="container">
                <div class="row g-4">
                    <!-- Left Side: Gallery & Specs -->
                    <div class="col-lg-7 col-12">
                        <!-- Image Slider Container -->
                        <div class="gallery-main" style="position: relative;">
                            <a id="mainGalleryLink" href="#" style="display: block;">
                                <img id="mainGalleryImg" src="<?= htmlspecialchars($images[0]) ?>" alt="Featured Room Image" style="cursor: zoom-in; width: 100%; display: block;">
                            </a>
                            <div id="galleryCountOverlay" style="position: absolute; bottom: 15px; right: 15px; background: rgba(15, 23, 42, 0.75); color: #fff; font-size: 11px; padding: 4px 10px; border-radius: 20px; font-weight: 700; letter-spacing: 0.5px; z-index: 2;">
                                <span id="currentImgNum">1</span> / <?= count($images) ?> Images
                            </div>
                        </div>

                        <!-- Hidden anchors for full gallery popup -->
                        <div style="display: none;">
                            <?php foreach ($images as $index => $img_path): ?>
                                <a href="<?= htmlspecialchars($img_path) ?>" class="room-gallery-link" data-index="<?= $index ?>"></a>
                            <?php endforeach; ?>
                        </div>
                        <?php if (count($images) > 1): ?>
                            <div class="gallery-thumbs mb-15">
                                <?php foreach ($images as $index => $img_path): ?>
                                    <div class="gallery-thumb <?= $index === 0 ? 'active' : '' ?>" onclick="switchGalleryImg(this, '<?= htmlspecialchars($img_path) ?>')">
                                        <img src="<?= htmlspecialchars($img_path) ?>" alt="Thumbnail">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <!-- Overview Card -->
                        <div class="detail-card">
                            <h3>Room Overview</h3>
                            <div style="font-size: 15px; line-height: 1.75; color: #4b5563; font-weight:500; margin-bottom: 0;">
                                <?= $room['description'] ?>
                            </div>

                            <!-- Key Technical Specifications -->
                            <div class="specs-grid">
                                <div class="spec-item">
                                    <div class="spec-icon">👥</div>
                                    <div class="spec-info">
                                        <span class="spec-label">Capacity Limit</span>
                                        <span class="spec-value"><?= htmlspecialchars($room['capacity_adults'] ?? 2) ?> Adults, <?= htmlspecialchars($room['capacity_children'] ?? 1) ?> Child</span>
                                    </div>
                                </div>
                                <div class="spec-item">
                                    <div class="spec-icon">🛏️</div>
                                    <div class="spec-info">
                                        <span class="spec-label">Bed Setup</span>
                                        <span class="spec-value">Comfort King Bed</span>
                                    </div>
                                </div>
                                <div class="spec-item">
                                    <div class="spec-icon">⚡</div>
                                    <div class="spec-info">
                                        <span class="spec-label">Reservations</span>
                                        <span class="spec-value">Instant Payment</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Amenities List -->
                        <div class="detail-card">
                            <h3>Amenities Included</h3>
                            <div class="amenity-grid">
                                <?php foreach ($facilities as $fac): ?>
                                    <div class="amenity-item">
                                        <span class="amenity-check">✓</span>
                                        <span><?= htmlspecialchars($fac) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Right Side: Config Stay Form -->
                    <div class="col-lg-5 col-12">
                        <div class="detail-card sticky-form-sidebar">
                            <h3 style="border-bottom:none; margin-bottom:15px; padding-bottom:0;">Configure Stay & Meal Plan</h3>

                            <form id="stayConfigForm" method="GET" action="checkout.php">
                                <input type="hidden" name="room" value="<?= htmlspecialchars($room['slug']) ?>">

                                <div class="row g-2 mb-10">
                                    <div class="col-6">
                                        <label class="form-label-custom" style="font-size:11.5px; font-weight:700;">Check-In Date *</label>
                                        <input id="detailCheckIn" class="form-control-custom" type="date" name="checkin" value="<?= htmlspecialchars($checkin) ?>" min="<?= date('Y-m-d') ?>" required style="height:38px; font-size:12.5px;">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label-custom" style="font-size:11.5px; font-weight:700;">Check-Out Date *</label>
                                        <input id="detailCheckOut" class="form-control-custom" type="date" name="checkout" value="<?= htmlspecialchars($checkout) ?>" min="<?= date('Y-m-d') ?>" required style="height:38px; font-size:12.5px;">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label-custom" style="font-size:11.5px; font-weight:700;">Adult Guests *</label>
                                        <input id="detailAdults" class="form-control-custom" type="number" name="adults" value="<?= htmlspecialchars($adults) ?>" min="1" max="5" required style="height:38px; font-size:12.5px;">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label-custom" style="font-size:11.5px; font-weight:700;">Child Guests</label>
                                        <input id="detailChildren" class="form-control-custom" type="number" name="children" value="<?= htmlspecialchars($children) ?>" min="0" max="2" required style="height:38px; font-size:12.5px;" onchange="updateDetailChildAgesFields()">
                                    </div>
                                </div>

                                <div class="col-12" id="detailChildAgesWrapper" style="display: none; margin-bottom: 15px; margin-top: 10px;">
                                    <label class="form-label-custom" style="font-size: 11.5px; font-weight: 700; color: #9c6047;">Specify Child Ages *</label>
                                    <div id="detailChildAgesFields" class="row g-2"></div>
                                    <div id="detailOccupancyWarning" class="text-danger mt-2" style="display: none; font-size: 11.5px; font-weight: 700; background: #fff5f5; border: 1px solid #ffe3e3; padding: 6px 10px; border-radius: 4px;"></div>
                                    <span style="font-size: 10.5px; color: #64748b; display: block; margin-top: 4px;">* Child Policy: Children under 8 years stay free. Children 8 years and above pay child rates.</span>
                                </div>

                                <label class="form-label-custom mb-10" style="display:block; font-weight:700;">Select Tariff Meal Plan *</label>

                                <!-- EP Card -->
                                <div class="tariff-option-card selected" onclick="selectTariffPlan(this, 'EP')">
                                    <div class="tariff-content">
                                        <div class="tariff-title">Stay Only</div>
                                        <div class="tariff-desc">Room only inclusion. Access to hotel Wi-Fi and common properties.</div>
                                        <div class="tariff-price">₹<span id="rateEP">0.00</span> <span style="font-size:11px; font-weight:normal; color:#64748b;">/ night</span></div>
                                    </div>
                                    <div class="tariff-radio"></div>
                                    <input type="radio" name="meal_plan" value="EP" checked>
                                </div>

                                <!-- CP Card -->
                                <div class="tariff-option-card" onclick="selectTariffPlan(this, 'CP')">
                                    <div class="tariff-content">
                                        <div class="tariff-title">Stay with Breakfast</div>
                                        <div class="tariff-desc">Stay includes standard room and delicious daily Morning Breakfast buffet.</div>
                                        <div class="tariff-price">₹<span id="rateCP">0.00</span> <span style="font-size:11px; font-weight:normal; color:#64748b;">/ night</span></div>
                                    </div>
                                    <div class="tariff-radio"></div>
                                    <input type="radio" name="meal_plan" value="CP">
                                </div>

                                <!-- MAP Card -->
                                <div class="tariff-option-card" onclick="selectTariffPlan(this, 'MAP')">
                                    <div class="tariff-content">
                                        <div class="tariff-title">Stay with Breakfast, Lunch or Dinner</div>
                                        <div class="tariff-desc">Stay includes Morning Breakfast and either Lunch or Dinner buffet plan.</div>
                                        <div class="tariff-price">₹<span id="rateMAP">0.00</span> <span style="font-size:11px; font-weight:normal; color:#64748b;">/ night</span></div>
                                    </div>
                                    <div class="tariff-radio"></div>
                                    <input type="radio" name="meal_plan" value="MAP">
                                </div>

                                <!-- Stay Billing Cost Calculations Summary Panel -->
                                <div class="p-15 mt-15 mb-15" style="background:#fafaf9; border-radius:12px; border:1px solid #f0f0ed; font-size:13.5px; font-weight:600; color:#475569;">
                                    <div class="d-flex justify-content-between mb-8">
                                        <span style="color:#64748b;">Nights Count:</span>
                                        <span style="color:var(--charcoal);"><span id="stayNights">1</span> Night(s)</span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-8">
                                        <span style="color:#64748b;">Stay Rate Subtotal:</span>
                                        <span style="color:var(--charcoal);">₹<span id="subtotalCost">0.00</span></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-12">
                                        <span style="color:#64748b;">GST Taxes (5%):</span>
                                        <span style="color:var(--charcoal);">₹<span id="taxCost">0.00</span></span>
                                    </div>
                                    <div class="d-flex justify-content-between pt-12" style="border-top:1px dashed #cbd5e1; font-size:16px; font-weight:800; color:#15803d;">
                                        <span>Total Stay Price:</span>
                                        <span>₹<span id="totalCost">0.00</span></span>
                                    </div>
                                </div>

                                <button class="btn-book-online" type="submit">
                                    Next
                                    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"></path>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include("include/footer.php"); ?>

    <!-- Scripts -->
    <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="assets/js/plugins/magnific-popup.js"></script>

    <script>
        // Build pricing matrix dynamically from database values
        const pricingMatrix = {
            single: {
                EP: <?= floatval($room['price_single_ep'] ?? 0) ?>,
                CP: <?= floatval($room['price_single_cp'] ?? 0) ?>,
                MAP: <?= floatval($room['price_single_map'] ?? 0) ?>
            },
            double: {
                EP: <?= floatval($room['price_double_ep'] ?? 0) ?>,
                CP: <?= floatval($room['price_double_cp'] ?? 0) ?>,
                MAP: <?= floatval($room['price_double_map'] ?? 0) ?>
            },
            triple: {
                EP: <?= floatval($room['price_triple_ep'] ?? 0) ?>,
                CP: <?= floatval($room['price_triple_cp'] ?? 0) ?>,
                MAP: <?= floatval($room['price_triple_map'] ?? 0) ?>
            }
        };

        var galleryImages = <?= json_encode($images) ?>;
        var currentGalleryIdx = 0;

        function autoSlideGallery() {
            if (galleryImages.length <= 1) return;
            currentGalleryIdx++;
            if (currentGalleryIdx >= galleryImages.length) {
                currentGalleryIdx = 0;
            }
            var thumb = $('.gallery-thumb').eq(currentGalleryIdx);
            if (thumb.length > 0) {
                switchGalleryImgHelper(thumb[0], galleryImages[currentGalleryIdx]);
            }
        }

        var autoSlideInterval = setInterval(autoSlideGallery, 3000);

        function switchGalleryImgHelper(element, imgPath) {
            $('.gallery-thumb').removeClass('active');
            $(element).addClass('active');
            $('#mainGalleryImg').attr('src', imgPath);
            $('#mainGalleryLink').attr('href', imgPath);
            var idx = $('.gallery-thumb').index(element);
            $('#currentImgNum').text(idx + 1);
        }

        function switchGalleryImg(element, imgPath) {
            clearInterval(autoSlideInterval);
            switchGalleryImgHelper(element, imgPath);
            currentGalleryIdx = $('.gallery-thumb').index(element);
        }

        function selectTariffPlan(element, planCode) {
            $('.tariff-option-card').removeClass('selected');
            $(element).addClass('selected');
            $(element).find('input[type="radio"]').prop('checked', true);
            recalculateStayTotals();
        }

        function recalculateStayTotals() {
            var checkIn = $('#detailCheckIn').val();
            var checkOut = $('#detailCheckOut').val();
            var adults = parseInt($('#detailAdults').val()) || 2;
            var children = parseInt($('#detailChildren').val()) || 0;
            var childAges = [];
            $('.detail-child-age-input').each(function() {
                var age = parseInt($(this).val()) || 0;
                childAges.push(age);
            });
            var roomId = <?= intval($room['id']) ?>;

            if (!checkIn || !checkOut) return;

            $.ajax({
                url: 'checkout.php',
                method: 'POST',
                data: {
                    action: 'get_pricing',
                    check_in: checkIn,
                    check_out: checkOut,
                    adults: adults,
                    children: children,
                    child_ages: childAges,
                    room_id: roomId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var nights = response.nights;
                        $('#stayNights').text(nights);

                        $('#rateEP').text(response.ep_average_rate.toFixed(2));
                        $('#rateCP').text(response.cp_average_rate.toFixed(2));
                        $('#rateMAP').text(response.map_average_rate.toFixed(2));

                        var selectedPlan = $('input[name="meal_plan"]:checked').val() || 'EP';
                        var subtotal = 0;
                        if (selectedPlan === 'CP') {
                            subtotal = response.cp_base_price;
                        } else if (selectedPlan === 'MAP') {
                            subtotal = response.map_base_price;
                        } else {
                            subtotal = response.ep_base_price;
                        }

                        var tax = subtotal * 0.05; // 5% GST
                        var total = subtotal + tax;

                        $('#subtotalCost').text(subtotal.toFixed(2));
                        $('#taxCost').text(tax.toFixed(2));
                        $('#totalCost').text(total.toFixed(2));

                        if (total <= 0) {
                            $('.btn-book-online').prop('disabled', true);
                        } else {
                            var adults = parseInt($('#detailAdults').val()) || 2;
                            var children = parseInt($('#detailChildren').val()) || 0;
                            var hasOccupancyError = (adults > 3 || (adults === 3 && children > 0));
                            if (!hasOccupancyError) {
                                $('.btn-book-online').prop('disabled', false);
                            }
                        }
                    }
                }
            });
        }

        // Initial loaded child ages from URL query parameter
        var preLoadedAges = <?= json_encode($child_ages) ?>;
        var initialRun = true;

        function enforceDetailOccupancy() {
            var adults = parseInt($('#detailAdults').val()) || 2;
            if (adults >= 3) {
                if (adults > 3) {
                    $('#detailAdults').val(3);
                }
                $('#detailChildren').val(0).attr('max', 0);
            } else {
                $('#detailChildren').attr('max', 2);
            }
        }

        function updateCheckoutMinDate() {
            var checkInVal = $('#detailCheckIn').val();
            var updated = false;
            if (checkInVal) {
                var parts = checkInVal.split('-');
                var checkInDate = new Date(parts[0], parts[1] - 1, parts[2]);
                checkInDate.setDate(checkInDate.getDate() + 1);

                var yyyy = checkInDate.getFullYear();
                var mm = String(checkInDate.getMonth() + 1).padStart(2, '0');
                var dd = String(checkInDate.getDate()).padStart(2, '0');
                var minCheckoutDate = yyyy + '-' + mm + '-' + dd;

                $('#detailCheckOut').attr('min', minCheckoutDate);

                var checkOutVal = $('#detailCheckOut').val();
                if (!checkOutVal || checkOutVal <= checkInVal) {
                    $('#detailCheckOut').val(minCheckoutDate);
                    updated = true;
                }
            }
            return updated;
        }

        function updateDetailChildAgesFields() {
            enforceDetailOccupancy();
            var numChildren = parseInt($('#detailChildren').val()) || 0;
            var wrapper = $('#detailChildAgesWrapper');
            var fieldsContainer = $('#detailChildAgesFields');

            if (numChildren > 0) {
                var currentSelected = [];
                if (initialRun && preLoadedAges && preLoadedAges.length > 0) {
                    currentSelected = preLoadedAges;
                    initialRun = false;
                } else {
                    $('.detail-child-age-input').each(function() {
                        currentSelected.push($(this).val());
                    });
                }

                fieldsContainer.empty();
                for (var i = 1; i <= numChildren; i++) {
                    var val = currentSelected[i - 1] || '5'; // default to 5 (free)
                    var optionsHtml = '';
                    for (var age = 0; age <= 17; age++) {
                        var label = age === 0 ? '0 years (Infant)' : (age + ' year' + (age > 1 ? 's' : ''));
                        optionsHtml += `<option value="${age}" ${age == val ? 'selected' : ''}>${label}</option>`;
                    }
                    var fieldHtml = `
                        <div class="col-6">
                            <div class="form-group mb-2">
                                <label class="form-label-custom" style="font-size:11px;">Child ${i} Age</label>
                                <select class="form-control-custom detail-child-age-input" name="child_ages[]" style="height:38px; width:100%; padding: 0 10px; font-size:12.5px;">
                                    ${optionsHtml}
                                </select>
                            </div>
                        </div>
                    `;
                    fieldsContainer.append(fieldHtml);
                }
                wrapper.show();
                $('.detail-child-age-input').off('change').on('change', function() {
                    checkDetailEffectiveOccupancy();
                    recalculateStayTotals();
                });
            } else {
                fieldsContainer.empty();
                wrapper.hide();
            }
            checkDetailEffectiveOccupancy();
        }

        function checkDetailEffectiveOccupancy() {
            var adults = parseInt($('#detailAdults').val()) || 2;
            var children = parseInt($('#detailChildren').val()) || 0;

            var errorMsg = '';
            if (adults > 3) {
                errorMsg = 'Exceeds max room capacity of 3 adults.';
            } else if (children > 2) {
                errorMsg = 'A maximum of 2 children is allowed per room.';
            } else if (adults === 3 && children > 0) {
                errorMsg = 'Children not allowed when reserving for 3 adults.';
            }

            if (errorMsg) {
                $('#detailOccupancyWarning').text(errorMsg).show();
                $('.btn-book-online').prop('disabled', true);
            } else {
                $('#detailOccupancyWarning').hide();
                var totalVal = parseFloat($('#totalCost').text()) || 0;
                if (totalVal > 0) {
                    $('.btn-book-online').prop('disabled', false);
                } else {
                    $('.btn-book-online').prop('disabled', true);
                }
            }
        }

        $(document).ready(function() {
            // Set min date on page load
            updateCheckoutMinDate();

            // Date validation sync
            $('#detailCheckIn').change(function() {
                var wasUpdated = updateCheckoutMinDate();
                if (wasUpdated) {
                    $('#detailCheckOut').trigger('change');
                } else {
                    updateDetailChildAgesFields();
                    recalculateStayTotals();
                }
            });

            $('#detailCheckOut').change(function() {
                updateDetailChildAgesFields();
                recalculateStayTotals();
            });

            // Recalculate cost and enforce occupancy when guest counts change
            $('#detailAdults, #detailChildren').on('change input', function() {
                updateDetailChildAgesFields();
                recalculateStayTotals();
            });

            // Initial calculation run
            updateDetailChildAgesFields();
            recalculateStayTotals();

            // Initialize Magnific Popup for room gallery
            $('.room-gallery-link').magnificPopup({
                type: 'image',
                gallery: {
                    enabled: true,
                    navigateByImgClick: true,
                    preload: [0, 1]
                },
                mainClass: 'mfp-fade',
                removalDelay: 300
            });

            // Click handler for main image link
            $('#mainGalleryLink').on('click', function(e) {
                e.preventDefault();
                var currentIndex = $('.gallery-thumb.active').index();
                if (currentIndex < 0) currentIndex = 0;
                $('.room-gallery-link').eq(currentIndex).trigger('click');
            });

            // Prevent booking submission if total cost is 0 or occupancy warning exists
            $('#stayConfigForm').on('submit', function(e) {
                var totalVal = parseFloat($('#totalCost').text()) || 0;
                var warningVisible = $('#detailOccupancyWarning').is(':visible');
                if (totalVal <= 0 || warningVisible) {
                    e.preventDefault();
                    return false;
                }
            });
        });
    </script>
</body>

</html>