<?php
// Prevent direct file access if loaded independently
if (count(get_included_files()) === 1) {
    http_response_code(403);
    exit("Direct access not permitted.");
}

// Start secure sessions
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 1 : 0);
    session_start();
}

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// =========================================================================
// Search Engine Indexing Switch
// Set to false: Instantly sends "noindex, nofollow" to ALL pages on the site.
// Set to true:  Enables Google, Bing & other search engines to index normally.
// =========================================================================
define('ENABLE_SEARCH_INDEXING', false);

if (!ENABLE_SEARCH_INDEXING) {
    if (!headers_sent()) {
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet', true);
    }
}

// System Constants
define('SITE_NAME', 'Hotel Destin Gwalior');
define('SITE_URL', 'https://hoteldestin.in');

// Database Credentials (Laragon default MySQL)
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'hotel_destin');
define('DB_USER', 'root');
define('DB_PASS', '');

// SMTP Email Configurations (Titan/GoDaddy Setup)
define('SMTP_HOST', 'smtpout.secureserver.net');
define('SMTP_PORT', 465);
define('SMTP_USER', 'info@hoteldestin.in');
define('SMTP_PASS', 'gU3_2VYVd');
define('SMTP_FROM', 'info@hoteldestin.in');
define('SMTP_FROM_NAME', 'Hotel Destin System');
define('OWNER_EMAIL', 'info@hoteldestin.in'); // Admin email recipient

// WhatsApp Notifications (Meta Cloud API Settings)
define('WHATSAPP_NOTIFICATION_ENABLED', true);
define('META_WA_ACCESS_TOKEN', 'EAAOoKc3ZBJ8IBSCyoS30n77lM6YoK1923OoaLVsRVACCaMDaYqguY5TH1xLPYOMtYbuLPBJWZAqhtwLrtuI2na5qZCpqdMxXaie2sKXLn775KdZB7Yrais3rZAbuaijjZA4YtuYrRn3wSbjrZATEN1JsaueZBmrRpZCpbydoZAg7bnA9cGuZBGo8lGYsc6pjvCUXQZDZD');
define('META_WA_PHONE_NUMBER_ID', '1298330143364557');
define('META_WA_BUSINESS_ACCOUNT_ID', '919220853849130');
define('WHATSAPP_RECEIVER_NUMBER', '919873272462'); // Phone number to receive alerts (include country code, no + or spaces)

// Razorpay Credentials & Payment Switch
// Set to true to enable online Razorpay checkout, or false to use Pay at Hotel only
define('ONLINE_PAYMENT_ENABLED', false);
define('RAZORPAY_KEY_ID', 'rzp_test_placeholder_key');
define('RAZORPAY_KEY_SECRET', 'rzp_test_placeholder_secret');

// Core Helper: Check CSRF token validation
function verify_csrf_token($token)
{
    return !empty($token) && hash_equals($_SESSION['csrf_token'], $token);
}

// Core Helper: XSS Sanitization
function sanitize($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
